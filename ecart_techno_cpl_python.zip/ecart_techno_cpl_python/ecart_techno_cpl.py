import pandas as pd
import numpy as np
import functions as fc
import imlconnect
from datetime import datetime, timedelta
import time

print("Objectif du script :\n")
print("Détecter des écarts techno CPL (C G1 sur K G3 , C G3 sur K G1) qui n'ont pas de Dossier d'Analyse Ecart Techno CPL en cours. \n")
print("Entrez la date du jour svp ?\n")

j = input("Jour ? (format numérique svp!)\n")
while len(j)!=2:
    j = input("Jour ? (2 caractères et format numérique svp!)\n")
while True:
    try:
        val = int(str(j))
        while val<1 or val>31:
            j = input("Jour ? Entre 01 et 31 svp!)\n") 
            val = int(str(j))
    except ValueError:
        # Not a valid number
        print("Ce n'est pas un nombre entier\n")
        j = input("Jour ? (format numérique svp!)\n")
    else:
        print("Succès !\n")
        # No error; stop the loop
        break  

m = input("Mois ? (format numérique svp!)\n")
while len(m)!=2:
    m = input("Mois ? (2 caractères et format numérique svp!)\n")
while True:
    try:
        val1 = int(str(m))
        while val1<1 or val1>12:
            m = input("Mois ? Entre 01 et 12 svp!)\n") 
            val1 = int(str(m))
    except ValueError:
        # Not a valid number
        print("Ce n'est pas un nombre entier\n")
        m = input("Mois ? (format numérique svp!)\n")
    else:
        print("Succès !\n")# No error; stop the loop
        break

a = input("Année en cours? (format numérique svp!)\n")
while len(a)!=4:
    a = input("Année ? (4 caractères et format numérique svp!)\n")
while True:
    try:
        val2 = int(str(a))
        while val2!=datetime.now().year:
            a = input("Année doit être année en cours svp!)\n") 
            val2 = int(str(a))
    except ValueError:
        # Not a valid number
        print("Ce n'est pas un nombre entier\n")
        a = input("Année ? (format numérique svp!)\n")
    else:
        print("Succès !\n")# No error; stop the loop
        break

date_saisie = pd.to_datetime(str(val2)+"-"+str(val1)+"-"+str(val)).strftime("%Y-%m-%d")
print("On va récupérer les données dans LinkyPilot en fonction de l'index date (J-1), vous devez retirer 1 jour à la date saisie.\n")
Q = input("Voulez retirer des jours à la date d'analyse ? oui ou non ?\n")
while Q!='oui' and Q!='non':
    print("Ecrivez correctement oui ou non en minuscule svp!\n")
    Q = input("Voulez retirer des jours à la date d'analyse ? oui ou non ?\n")
if Q=="oui":
    jour_à_retirer = input("Entrer le nombre de jour à retirer svp ?\n")
    while True:
        try:
            jour_à_retirer = int(str(jour_à_retirer))
        except ValueError:
            print("Ce n'est pas un nombre entier\n")
            jour_à_retirer = input("Entrez un nombre entier svp ?\n")
        else:
            print("Succès !\n")
            break
    date_analyse = pd.to_datetime(date_saisie) - timedelta(days=jour_à_retirer)
    date_analyse = date_analyse.strftime("%Y-%m-%d")
             
elif Q=='non':
    date_analyse = pd.to_datetime(date_saisie) - timedelta(days=0)
    date_analyse = date_analyse.strftime("%Y-%m-%d")
print("La date d'analyse est : \n",date_analyse) 
print("La date saisie est : \n",date_saisie)
print("Veuillez attendre jusqu'à la fin du traitement svp !\n")
start = time.process_time()

chemin = "/var/projects/iml/rstudio/PPEO/11_Creation_DA_EcartTechnoCPL/"

# Nouvelle source plus récente à utiliser /  : https://dataviz.enedis.fr/t/LinkyPilot/views/HYP-REG-014-IncompatibilitesCetK/IncompatibilitsC-Kactuelles/
# 04/10/2022 : il faut maintenant télécharger en mode Tableau Croisé Excel le Inco J T , et convertir en CSV
# ================> renommer les en têtes du CSV en PDC_ID_C;ECART

# 1) Importer un fichier externe provenant d'un rapport LinkyPilot qui contient la liste des écarts techno
df_Liste_C = pd.read_csv(chemin+"src/ECART_TECHNO.csv", sep=';')


# Importer le fichier de maintenance Cube 2 colonnes au format CSV
# Ne garder dan l'onglet STOCK_SEMAINE que les colonnes reference_m et statut
# CSV et convertir en UTF8 tout court
df_MAINTENANCE_C = pd.read_csv(chemin+"src/maintenance.csv", sep=';')

my_conn_sup = imlconnect.Sql("lsup_conn", 
                  key_path='/var/projects/iml/rstudio/D86553/python_conn/imlconnect.key', 
                  config_file_path='/var/projects/iml/rstudio/D86553/python_conn/config_imlconnect.yml',
                  open_connection=True)

sql_ini = "select PDC_ID, PDC_ID_C, PDC_ID_PRM_CONSO,PDC_DATE_POSE,PDC_PDK_COM_FK, PDC_PDK_MERC_FK, PDC_STATUT_FK from lspmet.t_pdc inner join filter_list f on f.val = t_pdc.pdc_id_c where PDC_PDK_MERC_FK is not null and pdc_statut_fk=1"
#Fonction de creation complete du sql avec df = dataframe, value = Colonne du tableau utilisé pour filtre, sql_init = sql à executer  
sql = fc.create_sql_with_df(df_Liste_C,'PDC_ID_C',sql_ini)


# 2) Récupérer les infos de LinkySUP, uniquement si le PDC est à l'état Posé et si le PDK_MERC (PDK référent) n'est pas nul (indispensable pour détecter un écart techno)
df_Liste_PDC = my_conn_sup.query(sql)

df_Liste_PDC = df_Liste_PDC[df_Liste_PDC.pdc_date_pose <= datetime.now() - timedelta(days=8)]

# Recherche des DA Ecart Techno C (clos ou en cours)
df_DA_ECART_TECHNO_C = my_conn_sup.query("""select PDC_ID , PDC_ID_C,  DAN_NNI_OUVERTURE, DA.DAN_NUMERO_DOSSIER NUMERO_DA, statut_da.sda_libelle STATUT_DA 
                                                    from lspmet.t_dossier_analyse DA
                                                    join lspmet.T_ref_statut_dossier_analyse statut_da on DA.DAN_STATUT_DOSSIER_ANALYSE_FK = statut_da.sda_id
                                                    join lspmet.t_dysfonctionnement DYS on DYS.DYS_ID= DA.DAN_DYSFONCTIONNEMENT_FK
                                                    JOIN lspmet.T_REF_TYPE_DYSFONCTIONNEMENT TDY ON DYS.DYS_TYPE_DYSFONCTIONNEMENT_FK = TDY.TDY_ID
                                                    JOIN lspmet.t_pdc on dys_id_objet = pdc_id
                                                    WHERE TDY_ID in (56)""")

# Recherche des DA Ecart Techno K (clos ou en cours)
df_DA_ECART_TECHNO_K = my_conn_sup.query("""select PDK_ID ,  DAN_NNI_OUVERTURE, DA.DAN_NUMERO_DOSSIER NUMERO_DA, statut_da.sda_libelle STATUT_DA 
                                            from lspmet.t_dossier_analyse DA
                                            join lspmet.T_ref_statut_dossier_analyse statut_da on DA.DAN_STATUT_DOSSIER_ANALYSE_FK = statut_da.sda_id
                                            join lspmet.t_dysfonctionnement DYS on DYS.DYS_ID= DA.DAN_DYSFONCTIONNEMENT_FK
                                            JOIN lspmet.T_REF_TYPE_DYSFONCTIONNEMENT TDY ON DYS.DYS_TYPE_DYSFONCTIONNEMENT_FK = TDY.TDY_ID
                                            JOIN lspmet.t_pdk on dys_id_objet = pdk_id
                                            WHERE TDY_ID in (58)""")


df_DA_ECART_TECHNO_C_STATS = df_DA_ECART_TECHNO_C[df_DA_ECART_TECHNO_C.statut_da != 'Clos'].assign(nb_da_c = 1).groupby(by=['pdc_id','pdc_id_c'],as_index=False).nb_da_c.sum()

df_DA_ECART_TECHNO_K_STATS = df_DA_ECART_TECHNO_K[df_DA_ECART_TECHNO_K.statut_da != 'Clos'].assign(nb_da_k = 1).groupby(by='pdk_id',as_index=False).nb_da_k.sum()

df_Croisement = df_Liste_C.rename(columns = {'PDC_ID_C':'pdc_id_c'}).merge( df_Liste_PDC,on = 'pdc_id_c',how='inner').merge(df_DA_ECART_TECHNO_C_STATS.drop('pdc_id',axis=1),on= 'pdc_id_c',how='left').merge(df_DA_ECART_TECHNO_K_STATS.rename(columns = {'pdk_id':'pdc_pdk_merc_fk'}),on= 'pdc_pdk_merc_fk', how = 'left')

df_Croisement = df_Croisement[df_Croisement.nb_da_c.isnull() & df_Croisement.nb_da_k.isnull()]

# Vérifier qu'il n'y a pas une DIT en cours via un autre DA sur ces PDC
sql_ini1 = """select DAN_NUMERO_DOSSIER NUMERO_DA, DYS.DYS_TYPE_DYSFONCTIONNEMENT_FK ID_DYS,
                                    DYS.DYS_ID_OBJET PDC, TDY.TDY_LIBELLE NOM_DA, statut_da.sda_libelle STATUT_DA,
                                    nvl(ACT_DATE_LANCEMENT,ACT_DATE_DEBUT) ACT_DATE_DEBUT, SAC_LIBELLE, TYA_LIBELLE, RAC_LIBELLE, SAC_ID 
                                    from lspmet.t_dysfonctionnement DYS 
                                    inner join filter_list f on f.val = DYS.DYS_ID_OBJET
                                    inner join lspmet.t_dossier_analyse DA on DA.DAN_DYSFONCTIONNEMENT_FK = DYS.DYS_ID
                                    JOIN lspmet.T_REF_TYPE_DYSFONCTIONNEMENT TDY ON DYS.DYS_TYPE_DYSFONCTIONNEMENT_FK = TDY.TDY_ID
                                    join lspmet.T_PDC on DYS_ID_OBJET=PDC_ID
                                    join lspmet.T_ref_statut_dossier_analyse statut_da on DA.DAN_STATUT_DOSSIER_ANALYSE_FK = statut_da.sda_id
                                    join lspmet.t_localisation_dossier lod on lod.lod_dossier_fk = da.dan_id
                                    join lspmet.t_ref_localisation_erdf loc on loc.loc_id=lod.lod_localisation_fk
                                    left join lspmet.T_ACTION AC on AC.ACT_DOSSIER_ANALYSE_FK=DA.DAN_ID
                                    left join lspmet.T_REF_STATUT_ACTION  TSA on TSA.SAC_ID=AC.ACT_STATUT_ACTION_FK
                                    left join lspmet.T_TYPE_ACTION TTA on TTA.TYA_ID = AC.ACT_TYPE_ACTION_FK
                                    left join lspmet.T_RESULTAT_ACTION TRA on AC.ACT_ACTION_RESULTAT_FK = TRA.RAC_ID
                                    where DA.DAN_STATUT_DOSSIER_ANALYSE_FK<>3 AND ACT_ACTION_COURANTE=1"""
#Fonction de creation complete du sql avec df = dataframe, value = Colonne du tableau utilisé pour filtre, sql_init = sql à executer  
sql1 = fc.create_sql_with_df(df_Croisement,'pdc_id',sql_ini1)


df_Actions_C = my_conn_sup.query(sql1)

df_Action_Actuelle_C = df_Actions_C.query("tya_libelle =='T020/DIT C' and id_dys==18 or id_dys==47 or id_dys==61")

# .drop_duplicates() suprrime les doublons du dataframe en entier
df_Actions_C.query("tya_libelle =='T020/DIT C' and id_dys==18 or id_dys==47 or id_dys==61").drop_duplicates()



df_Action_Actuelle_C_racc = pd.DataFrame({'pdc':df_Action_Actuelle_C.pdc.unique(),'exclusion_c':'oui'})


# Vérifier qu'il n'y a pas une DIT en cours via un autre DA sur ces PDC
sql_ini2 = """select DAN_NUMERO_DOSSIER NUMERO_DA, DYS.DYS_TYPE_DYSFONCTIONNEMENT_FK ID_DYS,DYS.DYS_ID_OBJET PDK, TDY.TDY_LIBELLE NOM_DA, statut_da.sda_libelle STATUT_DA, ACT_DATE_LANCEMENT ACT_DATE_DEBUT, SAC_LIBELLE, TYA_LIBELLE, RAC_LIBELLE, SAC_ID
                                    from lspmet.t_dysfonctionnement DYS 
                                    inner join filter_list f on f.val = DYS.DYS_ID_OBJET
                                    inner join lspmet.t_dossier_analyse DA on DA.DAN_DYSFONCTIONNEMENT_FK = DYS.DYS_ID
                                    JOIN lspmet.T_REF_TYPE_DYSFONCTIONNEMENT TDY ON DYS.DYS_TYPE_DYSFONCTIONNEMENT_FK = TDY.TDY_ID
                                    join lspmet.T_PDK on DYS_ID_OBJET=PDK_ID
                                    join lspmet.T_ref_statut_dossier_analyse statut_da on DA.DAN_STATUT_DOSSIER_ANALYSE_FK = statut_da.sda_id
                                    join lspmet.t_localisation_dossier lod on lod.lod_dossier_fk = da.dan_id
                                    join lspmet.t_ref_localisation_erdf loc on loc.loc_id=lod.lod_localisation_fk
                                    left join lspmet.T_ACTION AC on AC.ACT_DOSSIER_ANALYSE_FK=DA.DAN_ID
                                    left join lspmet.T_REF_STATUT_ACTION  TSA on TSA.SAC_ID=AC.ACT_STATUT_ACTION_FK
                                    left join lspmet.T_TYPE_ACTION TTA on TTA.TYA_ID = AC.ACT_TYPE_ACTION_FK
                                    left join lspmet.T_RESULTAT_ACTION TRA on AC.ACT_ACTION_RESULTAT_FK = TRA.RAC_ID
                                    where DA.DAN_STATUT_DOSSIER_ANALYSE_FK<>3 and ACT_ACTION_COURANTE=1"""
#Fonction de creation complete du sql avec df = dataframe, value = Colonne du tableau utilisé pour filtre, sql_init = sql à executer  
sql2 = fc.create_sql_with_df(df_Croisement,'pdc_pdk_merc_fk',sql_ini2)


df_Actions_K = my_conn_sup.query(sql2)



df_Action_Actuelle_K = df_Actions_K[df_Actions_K.id_dys==58].assign(exclusion_k='oui')
df_Action_Actuelle_K_racc = pd.DataFrame({'pdk':df_Action_Actuelle_K.pdk.unique(),'exclusion_k':'oui'})


df_Analyse = df_Croisement.merge(df_Action_Actuelle_C_racc.rename(columns={'pdc':'pdc_id'}),on='pdc_id',how = 'left').merge(df_Action_Actuelle_K_racc.rename(columns = {'pdk':'pdc_pdk_merc_fk'}), on = 'pdc_pdk_merc_fk',how='left').replace(np.nan,0)

filters = [
    (df_Analyse.nb_da_c ==1) | (df_Analyse.nb_da_k ==1),
    (df_Analyse.nb_da_c ==0) & (df_Analyse.nb_da_k ==0) & (df_Analyse.exclusion_c =='oui'),
    (df_Analyse.nb_da_c ==0) & (df_Analyse.nb_da_k ==0) & (df_Analyse.exclusion_c ==0)
]
values = ['DA Ecart Techno C ou K en cours','Intervention en attente Autre DA','Pas de DA et aucune intervention Autre DA']
df_Analyse = df_Analyse.assign(categorie = np.select(filters, values))

df_Analyse = df_Analyse[df_Analyse.categorie == 'Pas de DA et aucune intervention Autre DA'].merge(df_MAINTENANCE_C.rename(columns={'reference_m':'pdc_id_prm_conso'}),on='pdc_id_prm_conso',how='left').replace(np.nan,'aucune')



df_Analyse_Finale_Creation_DA =df_Analyse[['pdc_id_c','ECART','pdc_id', 'pdc_id_prm_conso','statut']].groupby('pdc_id',as_index=False).agg(nb_statuts = pd.NamedAgg(column ='pdc_id', aggfunc='count'))

df_Analyse_Finale_Creation_DA = df_Analyse_Finale_Creation_DA.merge(df_Analyse,on='pdc_id',how='right')


x=df_Analyse_Finale_Creation_DA.groupby(['pdc_id', 'nb_statuts', 'pdc_id_c', 'ECART', 'pdc_id_prm_conso','statut'],as_index=False).agg(nb_affaires = pd.NamedAgg(column ='pdc_id', aggfunc='count'))


stats = x.pivot_table(index= 'pdc_id',columns='statut', values= 'nb_affaires')
stats = stats.reset_index().rename_axis(None, axis = 1).replace(np.nan,0)
stats = stats.assign(categorie_finale = np.where(stats.édité>0,'Présence Affaire Editée','Aucune Affaire Editée'))
stats = stats[~stats.pdc_id.isin(['PDC00010360283','PDC00010335879','PDC00015055238'])].query("categorie_finale=='Aucune Affaire Editée'")

# Faire un CSV par type d'écart 
df_DA_EcartTechnoCPL_CG1_KG3 = df_Analyse_Finale_Creation_DA[df_Analyse_Finale_Creation_DA.ECART.isin(['C P0 G1 - K P1 G3','C P1 G1 - K P1 G3'])][['pdc_id']].rename(columns={'pdc_id':'pdc'}).reset_index(drop=True)  
df_DA_EcartTechnoCPL_CG3_KG1 = df_Analyse_Finale_Creation_DA[df_Analyse_Finale_Creation_DA.ECART=='C P1 G3 - K P1 G1'][['pdc_id']].rename(columns={'pdc_id':'pdc'}).reset_index(drop=True)  


stop = time.process_time()
print("Temps de traitement : ",stop-start," secondes\n")
print("Fin de traitement\n")

from dash import Dash, html, Input, Output, dash_table, State, dcc
import dash_bootstrap_components as dbc

app = Dash(__name__, external_stylesheets=[dbc.themes.MINTY])

app.layout = dbc.Container(
    [
        dbc.Row(
            [
                dbc.Col(
                    [html.H2("Script ecart techno CPL:", style={"text-align": "center","color":"blue"})]
                )
            ]
        ),
        dcc.Download(id="download"),
        dbc.Row(
            [
                dbc.Col(
                    [
                        html.Div([
        dcc.RadioItems(id="my_choice",options = 
   [
       {'label': "df_DA_EcartTechnoCPL_CG1_KG3", 'value': 'EcartTechnoCPL_CG1_KG3'},
       {'label': "df_DA_EcartTechnoCPL_CG3_KG1", 'value': 'EcartTechnoCPL_CG3_KG1'},
    
   ],
   value='EcartTechnoCPL_CG1_KG3'
          )
    ]),
                       
                    ]   
                ),
                dbc.Col(
                    
                        html.Div(id = 'check_output',style={"color":"red"})
                        )
                    
                
            ]
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dcc.Dropdown(
                            options=[
                                {"label": "CSV file", "value": "csv"},
                                {"label": "Excel file", "value": "xls"},
                            ],
                            id="dropdown",
                            placeholder="Choose download file type. Default is CSV format!",
                        )
                    ]
                ),
                dbc.Col(
                    [
                        dbc.Button(
                            "Download Data", id="btn_csv"
                        ),
                    ]
                ),
            ]
        ),
    ]
)



@app.callback(
   
    Output(component_id = 'check_output',component_property = 'children'),
 
    Input("my_choice", "value"),  
)
def update_output_div(my_choice_value):
    return f'Vous avez choisi : {my_choice_value}'

@app.callback(
    Output("download", "data"),
    Input("btn_csv", "n_clicks"),
    State("my_choice", "value"),
    State("dropdown", "value"),
    prevent_initial_call=True,
)
def func(n_clicks_btn,my_choice_value,download_type):
    if download_type == "csv" and my_choice_value =='EcartTechnoCPL_CG1_KG3':
        return dcc.send_data_frame(df_DA_EcartTechnoCPL_CG1_KG3.to_csv, "DA_EcartTechnoCPL_CG1_KG3.csv")
    elif download_type == "xls" and my_choice_value =='EcartTechnoCPL_CG1_KG3':
        return dcc.send_data_frame(df_DA_EcartTechnoCPL_CG1_KG3.to_excel, "DA_EcartTechnoCPL_CG1_KG3.xlsx")
    elif download_type == "csv" and my_choice_value =='EcartTechnoCPL_CG3_KG1':
        return dcc.send_data_frame(df_DA_EcartTechnoCPL_CG3_KG1.to_csv, "DA_EcartTechnoCPL_CG3_KG1.csv")
    elif download_type == "xls" and my_choice_value =='EcartTechnoCPL_CG3_KG1':
        return dcc.send_data_frame(df_DA_EcartTechnoCPL_CG3_KG1.to_excel, "DA_EcartTechnoCPL_CG3_KG1.xlsx")

if __name__ == "__main__":
    app.run_server(port=8886, host='0.0.0.0')
