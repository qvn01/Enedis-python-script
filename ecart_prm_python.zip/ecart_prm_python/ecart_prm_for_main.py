# -*- coding: utf-8 -*-
# On importe la librairie pandas puis on spécifie le chemin d'accès des 4 fichiers csv
import pandas as pd
import numpy as np
import functions as fc
import imlconnect
from datetime import datetime, timedelta
import time
start = time.process_time()

print("Entrez la date du jour svp ?\n")
j = input("Jour ? (format numérique svp!)\n")
while len(j)!=2:
    j = input("Jour ? (2 caractères et format numérique svp!)\n")
while True:
    try:
        val = int(str(j))
        while val<1 or val>31:
            j = input("Jour ? Entre 01 et 31 svp!)\n") 
            val = int(str(j))
    except ValueError:
        # Not a valid number
        print("Ce n'est pas un nombre entier\n")
        j = input("Jour ? (format numérique svp!)\n")
    else:
        print("Succès !\n")
        # No error; stop the loop
        break  

m = input("Mois ? (format numérique svp!)\n")
while len(m)!=2:
    m = input("Mois ? (2 caractères et format numérique svp!)\n")
while True:
    try:
        val1 = int(str(m))
        while val1<1 or val1>12:
            m = input("Mois ? Entre 01 et 12 svp!)\n") 
            val1 = int(str(m))
    except ValueError:
        # Not a valid number
        print("Ce n'est pas un nombre entier\n")
        m = input("Mois ? (format numérique svp!)\n")
    else:
        print("Succès !\n")# No error; stop the loop
        break

a = input("Année en cours? (format numérique svp!)\n")
while len(a)!=4:
    a = input("Année ? (4 caractères et format numérique svp!)\n")
while True:
    try:
        val2 = int(str(a))
        while val2!=datetime.now().year:
            a = input("Année doit être année en cours svp!)\n") 
            val2 = int(str(a))
    except ValueError:
        # Not a valid number
        print("Ce n'est pas un nombre entier\n")
        a = input("Année ? (format numérique svp!)\n")
    else:
        print("Succès !\n")# No error; stop the loop
        break


date_saisie = pd.to_datetime(str(val2)+"-"+str(val1)+"-"+str(val)).strftime("%Y-%m-%d")
print("On va récupérer les données dans LinkyPilot en fonction de l'index date (J-1), vous devez retirer 1 jour à la date saisie.\n")
print("Si les résultats ne sont pas satisfaisants, relancez ce script en retirant 2 jours (J-2).\n")
Q = input("Voulez retirer des jours à la date d'analyse ? oui ou non ?\n")
while Q!='oui' and Q!='non':
    print("Ecrivez correctement oui ou non en minuscule svp!\n")
    Q = input("Voulez retirer des jours à la date d'analyse ? oui ou non ?\n")
if Q=="oui":
    jour_à_retirer = input("Entrer le nombre de jour à retirer svp ?\n")
    while True:
        try:
            jour_à_retirer = int(str(jour_à_retirer))
        except ValueError:
            print("Ce n'est pas un nombre entier\n")
            jour_à_retirer = input("Entrez un nombre entier svp ?\n")
        else:
            print("Succès !\n")
            break

    date_analyse = pd.to_datetime(date_saisie) - timedelta(days=jour_à_retirer)
    date_analyse = date_analyse.strftime("%Y-%m-%d")

elif Q=='non':
    date_analyse = pd.to_datetime(date_saisie) - timedelta(days=0)
    date_analyse = date_analyse.strftime("%Y-%m-%d")

print("La date d'analyse est : \n",date_analyse) 
print("La date saisie est : \n",date_saisie)
print("Veuillez attendre jusqu'à la fin du traitement svp !\n")    

my_conn_rcm = imlconnect.Sql("rcm_conn", 
                      key_path='/var/projects/iml/rstudio/D86553/python_conn/imlconnect.key', 
                      config_file_path='/var/projects/iml/rstudio/D86553/python_conn/config_imlconnect.yml',
                      open_connection=True)



df_ECART_POSE_DECOUVERTE = my_conn_rcm.query("""select x.ID_C, x.prm_dec, y.prm_pose, y.id_pdc from (select /*+parallel(8)*/ lpad(id_c,12,'0') id_c,
                                       max(id_prm) keep (dense_rank first order by date_debut desc, date_maj desc) prm_dec
                                       from rcm.c_prm group by id_c) x
                                       inner join (select a.id_pdc, id_c , id_prm_conso prm_pose
                                       from rcm.cpdc_lien_courant a 
                                       inner join rcm.pdc_pdc b  on a.id_pdc = b.id_pdc where STATUT_LIEN_C_PDC = 2) y 
                                       on x.id_c = y.id_c and x.prm_dec<>y.prm_pose""")


sql_ini = "select PDC_ID as ID_PDC, DIS_ID,DIS_LIBELLE DISTRIBUTEUR, PDC_ID_PRM_CONSO PRM_POSE_SUP from lspmet.t_pdc inner join filter_list f on f.val = pdc_id inner join  lspmet.t_ref_distributeur on pdc_distributeur_fk=dis_id where pdc_statut_fk=3"
sql = fc.create_sql_with_df(df_ECART_POSE_DECOUVERTE,'id_pdc',sql_ini)


my_conn_sup = imlconnect.Sql("lsup_conn", 
                      key_path='/var/projects/iml/rstudio/D86553/python_conn/imlconnect.key', 
                      config_file_path='/var/projects/iml/rstudio/D86553/python_conn/config_imlconnect.yml',
                      open_connection=True)

df_T_PDC_RECO = my_conn_sup.query(sql)


df_ECART_POSE_DECOUVERTE = df_ECART_POSE_DECOUVERTE[df_ECART_POSE_DECOUVERTE.id_pdc!='PDC00016543785'].merge(df_T_PDC_RECO.rename(columns = {'prm_pose_sup':'prm_pose'}),on = ['id_pdc','prm_pose'],how = 'inner')


df_T_DA_ECART_PRM =   my_conn_sup.query("""select PDC_ID ,  DAN_NNI_OUVERTURE, DA.DAN_NUMERO_DOSSIER NUMERO_DA, TDY.TDY_LIBELLE NOM_DA, statut_da.sda_libelle STATUT_DA
                                       from lspmet.t_dossier_analyse DA
                                       join lspmet.T_ref_statut_dossier_analyse statut_da on DA.DAN_STATUT_DOSSIER_ANALYSE_FK = statut_da.sda_id
                                       join lspmet.t_dysfonctionnement DYS on DYS.DYS_ID= DA.DAN_DYSFONCTIONNEMENT_FK
                                       JOIN lspmet.T_REF_TYPE_DYSFONCTIONNEMENT TDY ON DYS.DYS_TYPE_DYSFONCTIONNEMENT_FK = TDY.TDY_ID
                                       JOIN lspmet.t_pdc on dys_id_objet = pdc_id
                                       WHERE TDY_ID in (33)""")

sql_ini1 = "select /*+parallel(8)*/ lpad(id_c,12,'0') id_c, max(id_prm) keep (dense_rank first order by date_debut asc, date_maj asc) PRM_PREMIERE_DECOUVERTE from rcm.c_prm inner join filter_list f on f.val = c_prm.id_c group by id_c"
sql1 = fc.create_sql_with_df(df_ECART_POSE_DECOUVERTE,'id_c',sql_ini1)


df_T_DECOUVERTE_C =  my_conn_rcm.query(sql1)

df_T_DA_ECART_PRM = df_T_DA_ECART_PRM.assign(Nb_Da = 1)



df_T_DA_ECART_PRM_groupé = df_T_DA_ECART_PRM.groupby(by=["pdc_id","statut_da"],as_index=False).Nb_Da.sum()



df_DERNIER_DA = df_T_DA_ECART_PRM.groupby(by="pdc_id",as_index=False).Nb_Da.sum().merge(df_T_DA_ECART_PRM.drop('Nb_Da',axis=1).sort_values(by="numero_da",ascending = False),on="pdc_id",how = 'inner')

# Statistiques 2
df_NB_DA_STATS = df_T_DA_ECART_PRM_groupé.pivot_table(index = "pdc_id", columns = "statut_da",values = "Nb_Da") 
df_NB_DA_STATS = df_NB_DA_STATS.reset_index().rename_axis(None, axis = 1)


df_NB_DA_STATS = df_NB_DA_STATS.replace(np.nan,0).rename(columns = {"Clos":"Nb_Da_Clos","En cours":"Nb_Da_en_cours"})



# Affiche le nombre total de valeur null d'une colonne : 
# syntaxe: nom_df.nom_col.isnull().sum()

# sans le .sum(), il affiche une colonne de booléen (True si null, False si non-null)

df_Analyse_Ecart_PRM_BILAN = pd.merge(df_ECART_POSE_DECOUVERTE, df_T_DECOUVERTE_C,on='id_c',how='left').merge(df_DERNIER_DA.rename(columns={'pdc_id':'id_pdc'}),on='id_pdc',how='left').merge(df_NB_DA_STATS.rename(columns={'pdc_id':'id_pdc'}),on='id_pdc',how='left')


df_Analyse_Ecart_PRM_BILAN = df_Analyse_Ecart_PRM_BILAN.replace({'Nb_Da_Clos': np.nan, 'Nb_Da_en_cours': np.nan}, 0)

# Je vérifie bien qu'il n'y a plus de valeur null, c'est le cas

df_eligibles = df_Analyse_Ecart_PRM_BILAN[df_Analyse_Ecart_PRM_BILAN.Nb_Da_en_cours == 0]



my_conn_pilot = imlconnect.Sql("pilot_conn", 
                      key_path='/var/projects/iml/rstudio/D86553/python_conn/imlconnect.key', 
                      config_file_path='/var/projects/iml/rstudio/D86553/python_conn/config_imlconnect.yml',
                      open_connection=True)


sql_ini2 = "select ID_PDC, ID_PDK_COM, NB_JOUR_NON_COLLECTE from lptdwh_dmt.FAIT_PDC FPDC inner join filter_list f on f.val = FPDC.id_pdc where id_jour=to_date('"+ date_analyse + "','yyyy-mm-dd')"
sql2 = fc.create_sql_with_df(df_eligibles,'id_pdc',sql_ini2)


# Rechercher dans Pilot le nombre de jour de non collecte
df_MyData_Collecte = my_conn_pilot.query(sql2)


# Ne conserver que les collectant et exclure les PINKY et les PRM 000 999 et PDK 69993
df_Ecart_PRM_TrouRaquette = df_Analyse_Ecart_PRM_BILAN.merge(df_MyData_Collecte,on='id_pdc',how = 'inner').query("nb_jour_non_collecte<=3")



df_Ecart_PRM_TrouRaquette = df_Ecart_PRM_TrouRaquette[~df_Ecart_PRM_TrouRaquette.prm_pose.str[0:4].isin(['9999','0000'])]


df_Ecart_PRM_TrouRaquette = df_Ecart_PRM_TrouRaquette[df_Ecart_PRM_TrouRaquette.id_pdk_com.str[0:2]!='99']
df_Ecart_PRM_TrouRaquette = df_Ecart_PRM_TrouRaquette[df_Ecart_PRM_TrouRaquette.id_pdk_com.str[0:5]!='69993']


# le .str accepte le type object de id_c mais j'ai qd même mis .astype(str) pour le transformer en str par précaution
df_Ecart_PRM_TrouRaquette = df_Ecart_PRM_TrouRaquette.assign(type_ec = df_Ecart_PRM_TrouRaquette.id_c.astype(str).str[0:2]+df_Ecart_PRM_TrouRaquette.id_c.astype(str).str[4:6])



df_Ecart_PRM_TrouRaquette = df_Ecart_PRM_TrouRaquette[~df_Ecart_PRM_TrouRaquette.id_pdc.isin(['PDC00028515571','PDC00028513592','PDC00028515765','PDC00028515874','PDC00028515031','PDC00028516114',
                        'PDC00028514487','PDC00028516317','PDC00028513753','PDC00028514259','PDC00028513529','PDC00028515446',
                        'PDC00028516229','PDC00028514632','PDC00028514647','PDC00028515137',
                        'PDC00028514210','PDC00028513363','PDC00028513238','PDC00028514838','PDC00028516265','PDC00028513475',
                        'PDC00028515324','PDC00028514383','PDC00028514348','PDC00028517308','PDC00028515216','PDC00028514970',
                        'PDC00028516624','PDC00028516551','PDC00028515394','PDC00028518462',
                        'PDC00028516653','PDC00028514738','PDC00028514532','PDC00028516451','PDC00028515610','PDC00028516148',
                        'PDC00028513242','PDC00028515855','PDC00028516431','PDC00028515985','PDC00028514451','PDC00028514924',
                        'PDC00028515502','PDC00028515123','PDC00028513585','PDC00028516017','PDC00028515253'])].query("type_ec !='0202' and type_ec !='0413'")



df_Analyse_Ecart_PRM_NonResolu = df_Ecart_PRM_TrouRaquette.query("Nb_Da_Clos>=1 and Nb_Da_en_cours ==0")

Df_Analyse_Ecart_PRM_PostReco = df_Ecart_PRM_TrouRaquette.query("Nb_Da_Clos==0 and Nb_Da_en_cours==0")



import os 
directory = os.getcwd()
rep = directory+"/export_ecart_prm/"

fc.split_df_to_csv(df_Analyse_Ecart_PRM_NonResolu,999,rep,date_saisie,"df_Analyse_Ecart_PRM_NonResolu")
fc.split_df_to_csv(Df_Analyse_Ecart_PRM_PostReco,999,rep,date_saisie,"Df_Analyse_Ecart_PRM_PostReco")
fc.split_df_to_csv(df_eligibles,999,rep,date_saisie,"df_eligibles")

import shutil as sh
sh.make_archive('export_ecart_prm','zip',rep)

stop = time.process_time()
print("Temps de traitement : ",stop-start," secondes\n")
print("Fin de traitement, vous pouvez télécharger les données !\n")



