"""
Created on Mon Nov 28 2022 08:38:28

@author: QN0BEEEL
"""
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import re

# Cette fonction prend en paramètres un df et le nom de sa colonne date ainsi que le nombre de jours à retrancher à la date du jour et retourne le df avec les lignes où la date est < à celle du jour retrancher du nb de jour entré en paramètre
def filtre_date(df,col_date,date,jour):
    df[col_date] = pd.to_datetime(df[col_date])
    seuil = pd.to_datetime(date)- timedelta(days = jour)
    result = df[df[col_date]<seuil]
    return result



        
# fonction pour diviser le df_résultat en plusieurs df et créer autant de fichier csv dans le répertoire en question
def split_df_to_csv(df,nb_rows,chemin,date,nom_export):
    reste = len(df.index) % nb_rows
    if reste >0:
        nb_df = len(df.index) // nb_rows +1
    else:
        nb_df = len(df.index) // nb_rows
    for id, df_i in  enumerate(np.array_split(df,indices_or_sections = nb_df,axis = 0)):
 
        df_i.to_csv(chemin+date+nom_export+"{id}.csv".format(id=id),index=False)
                
        
        
        
        
# fonction qui split le dataframe en X nombres de sous dataframe de nb_rows lignes (pour nous ça sera 1000) car SQL dev n'accepte pas plus de 1000 éléments pour requeter dans "table(sys.dbms_debug_vc2coll()"
def split_df(df,col_name,nb_rows):
    x = pd.DataFrame({col_name:df[col_name].unique()})
    reste = len(x) % nb_rows
    if reste >0:
        nb_df = len(x) // nb_rows +1
    else:
        nb_df = len(x) // nb_rows
    data = {}     
    for i in range(nb_df):
        data[i] = np.array_split(x,nb_df,axis = 0)[i]
    return data     
        

def check_df(df):
    if df:
        return(True)
    else :
        print("la list d'entrée est vide")  
        return(False)
        
# Fonction qui compile la chaine de caractere pour table(sys.dbms_debug_vc2coll()) en faisant un union de la chaine de caractères de nb_rows éléments
# elle prend en paramètre le df, le nom de la colonne qui sert à compiler la chaine de caractère et sql_init qui est un select des champs des tables voulu pour l'analyse 

def create_sql_with_df(df, value, sql_init): # La colonne "value" doit être de type string ou object, pas numeric (int ou float)
    #extraction de la colonne souhaité et split en 1000
    
    df_split = split_df(df, value, 999) 
    #Vefication du dictionnaire retournée 
    is_ok = check_df(df_split)

    #Si ok creation de la requête
    if is_ok == True : 
        for i in df_split : 
            if i == 0: 
                temp_rqt = 'select column_value as val from table(sys.dbms_debug_vc2coll('+ str(df_split[i].values.tolist()) +'))'
                
            else:
                temp_rqt = temp_rqt + ' union select column_value as val from table(sys.dbms_debug_vc2coll('+ str(df_split[i].values.tolist())+'))'
                
        temp_rqt = re.sub("\[|]","",temp_rqt)
        sql = "with filter_list as (" + temp_rqt + " ) " + sql_init
       
        return(sql)
    else : 
        return("")
    
           
