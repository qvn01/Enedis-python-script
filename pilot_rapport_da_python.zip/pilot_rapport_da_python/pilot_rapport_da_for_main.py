# -*- coding: utf-8 -*-
# Import des modules nécessaires : 

import pandas as pd
import numpy as np
import functions as fc
import imlconnect
from datetime import datetime, timedelta
import time
start = time.process_time()

print("Entrez la date du jour svp ?\n")
j = input("Jour ? (format numérique svp!)\n")
while len(j)!=2:
    j = input("Jour ? (2 caractères et format numérique svp!)\n")
while True:
    try:
        val = int(str(j))
        while val<1 or val>31:
            j = input("Jour ? Entre 01 et 31 svp!)\n") 
            val = int(str(j))
    except ValueError:
        # Not a valid number
        print("Ce n'est pas un nombre entier\n")
        j = input("Jour ? (format numérique svp!)\n")
    else:
        print("Succès !\n")
        # No error; stop the loop
        break  

m = input("Mois ? (format numérique svp!)\n")
while len(m)!=2:
    m = input("Mois ? (2 caractères et format numérique svp!)\n")
while True:
    try:
        val1 = int(str(m))
        while val1<1 or val1>12:
            m = input("Mois ? Entre 01 et 12 svp!)\n") 
            val1 = int(str(m))
    except ValueError:
        # Not a valid number
        print("Ce n'est pas un nombre entier\n")
        m = input("Mois ? (format numérique svp!)\n")
    else:
        print("Succès !\n")# No error; stop the loop
        break

a = input("Année en cours? (format numérique svp!)\n")
while len(a)!=4:
    a = input("Année ? (4 caractères et format numérique svp!)\n")
while True:
    try:
        val2 = int(str(a))
        while val2!=datetime.now().year:
            a = input("Année doit être année en cours svp!)\n") 
            val2 = int(str(a))
    except ValueError:
        # Not a valid number
        print("Ce n'est pas un nombre entier\n")
        a = input("Année ? (format numérique svp!)\n")
    else:
        print("Succès !\n")# No error; stop the loop
        break

date_saisie = pd.to_datetime(str(val2)+"-"+str(val1)+"-"+str(val)).strftime("%Y-%m-%d")
print("On va récupérer les données dans LinkyPilot en fonction de l'index date (J-1), vous devez retirer 1 jour à la date saisie.\n")
Q = input("Voulez retirer des jours pour l'analyse ? oui ou non ?\n")
while Q!='oui' and Q!='non':
    print("Ecrivez correctement oui ou non en minuscule svp!\n")
    Q = input("Voulez retirer des jours à la date d'analyse ? oui ou non ?\n")
if Q=="oui":
    jour_à_retirer = input("Entrer le nombre de jour à retirer svp ?\n")
    while True:
        try:
            jour_à_retirer = int(str(jour_à_retirer))
        except ValueError:
            print("Ce n'est pas un nombre entier\n")
            jour_à_retirer = input("Entrez un nombre entier svp ?\n")
        else:
            print("Succès !\n")
            break
    
    date_analyse = pd.to_datetime(date_saisie) - timedelta(days=jour_à_retirer)
    date_analyse = date_analyse.strftime("%Y-%m-%d")

elif Q=='non':
    date_analyse = pd.to_datetime(date_saisie) - timedelta(days=0)
    date_analyse = date_analyse.strftime("%Y-%m-%d")
print("La date d'analyse est : \n",date_analyse) 
print("La date saisie est : \n",date_saisie)
print("Veuillez attendre jusqu'à la fin du traitement svp !\n")


my_conn_sup = imlconnect.Sql("lsup_conn", 
                  key_path='/var/projects/iml/rstudio/D86553/python_conn/imlconnect.key', 
                  config_file_path='/var/projects/iml/rstudio/D86553/python_conn/config_imlconnect.yml',
                  open_connection=True)


df_da_prm_usine = my_conn_sup.query("""
    select LOC_CODE DR,PDC_ID , PDC_ID_C,  PDC_ID_PRM_DEC ID_PRM, PDC_PDK_COM_FK PDK_COM, DA.DAN_NUMERO_DOSSIER NUMERO_DA, statut_da.sda_libelle STATUT_DA , PDC_DATE_DECOUVERTE DATE_DECOUVERTE
                                           from lspmet.t_dossier_analyse DA
                                           join lspmet.T_ref_statut_dossier_analyse statut_da on DA.DAN_STATUT_DOSSIER_ANALYSE_FK = statut_da.sda_id
                                           join lspmet.t_dysfonctionnement DYS on DYS.DYS_ID= DA.DAN_DYSFONCTIONNEMENT_FK
                                           JOIN lspmet.T_REF_TYPE_DYSFONCTIONNEMENT TDY ON DYS.DYS_TYPE_DYSFONCTIONNEMENT_FK = TDY.TDY_ID
                                           JOIN lspmet.t_pdc on dys_id_objet = pdc_id
                                           join lspmet.t_localisation_dossier lod on lod.lod_dossier_fk = da.dan_id
                                           join lspmet.t_ref_localisation_erdf loc on loc.loc_id=lod.lod_localisation_fk
                                           WHERE TDY_ID = 34 and sda_id=2 and PDC_ID_PRM_DEC='00000000000000'
    """)




# On appelle la fonction filtre_date pour avoir notre df qui contient les lignes voulus
df_filtré = fc.filtre_date(df_da_prm_usine,"date_decouverte",date_saisie,10)
df_filtré = df_filtré.sort_values(by="date_decouverte",ascending = False).reset_index(drop = True)


sql_ini = "select ID_PDC, ID_PRM PRM_C_ARRET_COLLECTE, ID_PDK_COM PDK_COM, ID_COMPTEUR, NB_JOUR_NON_COLLECTE from lptdwh_dmt.fait_pdc fpdc inner join filter_list f on f.val = fpdc.ID_PDK_COM where nb_jour_non_collecte > 7 and nb_c_reconcilie = 1 and id_jour = to_date('"+ date_analyse + "','yyyy-mm-dd')"
#Fonction de creation complete du sql avec df = dataframe, value = Colonne du tableau utilisé pour filtre, sql_init = sql à executer  
sql = fc.create_sql_with_df(df_filtré,'pdk_com',sql_ini)


my_conn_pilot = imlconnect.Sql("pilot_conn", 
                      key_path='/var/projects/iml/rstudio/D86553/python_conn/imlconnect.key', 
                      config_file_path='/var/projects/iml/rstudio/D86553/python_conn/config_imlconnect.yml',
                      open_connection=True)

df_INFO_Collecte = my_conn_pilot.query(sql)


df_INFO_Collecte.nb_jour_non_collecte = pd.to_timedelta(df_INFO_Collecte.nb_jour_non_collecte,unit='days',errors='coerce')

# date_analyse = date_saisie - le nombre de jour retranché (en input)
df_INFO_Collecte_Analyse = df_INFO_Collecte.assign(date_arret_collecte = pd.to_datetime(date_analyse) - df_INFO_Collecte.nb_jour_non_collecte)


# On vérifie les compteurs en arrêt de collecte s'ils sont perdus dans Linkycoeur
df_Analyse = pd.merge(df_filtré,df_INFO_Collecte_Analyse,on ='pdk_com',how = 'inner' )
  # Pour rappel date de pose = date du compte-rendu de pose du technicien poseur
  # Date de découverte = date à laquelle le compteur a communiqué pour la première fois avec le concentrateur et le SI pour s'authentifier
  # Réconciliation nécessite le CR de pose accepté par le SI (LinkyParc) et la réussite de découverte 





  # chercher des correspondances entre DA PRM Usine et Infos de collecte FAIT_PDC
df_Analyse = df_Analyse.assign(delta_1 =  df_Analyse.date_decouverte - df_Analyse.date_arret_collecte)

# delta_1 = différence en unité Jours entre DATE DECOUVERTE ET DATE ARRET COLLECTE

df_Analyse.delta_1 = df_Analyse.delta_1.dt.components['days']



# je veux que la différence soit d'un jour ou moins
df_Analyse_delta = df_Analyse.query("delta_1 <=1 and delta_1 >=0")


# vu que les jour sont en nombre entier on peut aussi utilisé cette syntaxe:
df_Analyse[df_Analyse.delta_1.isin([0,1])]

df_Analyse_delta = df_Analyse_delta.assign(nb_correspondance = 1)

df_Analyse_delta = df_Analyse_delta.drop('nb_correspondance',axis=1).merge(df_Analyse_delta.drop('delta_1',axis=1).groupby(by= "pdc_id",as_index = False).nb_correspondance.sum(), on ='pdc_id', how='outer')



df_Analyse_delta = df_Analyse_delta.assign(nb_presence_c_arret = 1)
df_Analyse_delta = df_Analyse_delta.drop('nb_presence_c_arret',axis=1).merge(df_Analyse_delta.drop(['delta_1','nb_correspondance'],axis=1).groupby(by= "id_compteur",as_index = False).nb_presence_c_arret.sum(), on ='id_compteur', how='outer')




# Requête LinkyCoeur sur table CK_LIEN_COURANT (RCM = référentiel comptage, RDS = demandes de service, RDM = données mesurées)
# Requête sur ETAT_LIEN_C_K =1 (1 = Perdu, autre valeur = non perdu)
# Vérifier que la perte est l'état courant du C
# Je veux que mes compteurs en arrêt de collecte soient au statut PERDU = sur-vérification vis à vis de l'arrêt de collecte
my_conn_rcm = imlconnect.Sql("rcm_conn", 
                      key_path='/var/projects/iml/rstudio/D86553/python_conn/imlconnect.key', 
                      config_file_path='/var/projects/iml/rstudio/D86553/python_conn/config_imlconnect.yml',
                      open_connection=True)


sql_ini1 = "select DATE_DEBUT DATE_PERTE, LPAD(ID_C,12,'0') ID_COMPTEUR from rcm.ck_lien_courant l inner join filter_list f on f.val = l.ID_C where ETAT_LIEN_C_K=1"
sql1 = fc.create_sql_with_df(df_Analyse_delta,'id_compteur',sql_ini1)


df_Perte_ArretColl= my_conn_rcm.query(sql1)


df_Perte_ArretColl = df_Perte_ArretColl.assign(date_dern_com = df_Perte_ArretColl.date_perte - timedelta(seconds = 86400))




sql_ini2 = "select DATE_DEBUT DATE_DERN_PIL02, LPAD(ID_C,12,'0') ID_COMPTEUR from rcm.ck_lien_courant l inner join filter_list f on f.val = l.ID_C where ETAT_LIEN_C_K in (2,3)"
sql2 = fc.create_sql_with_df(df_Analyse_delta,'id_compteur',sql_ini2)

df_EtatCourant_CK_PIL02 = my_conn_rcm.query(sql2)



sql_ini3 = "select e.compteur_id serialnum, s.sous_type emplacement,type_parc type, sous_type_parc sous_type from lptdwh_ods.equipement e inner join filter_list f on f.val = e.compteur_id inner join lptdwh_ods.logistique l on e.equipement_id=l.equipement_id inner join lptdwh_ods.site s on l.site_id_arrivee = s.site_id where t_dernier_mouvement=1"
sql3 = fc.create_sql_with_df(df_Analyse_delta,'pdc_id_c',sql_ini3)

df_Infos_Emplacement = my_conn_pilot.query(sql3)



df_Analyse_Finale = pd.merge(df_Analyse_delta,df_Perte_ArretColl,on="id_compteur",how = "left")
df_Analyse_Finale = df_Analyse_Finale.assign(delta_2 = df_Analyse_Finale.date_decouverte - df_Analyse_Finale.date_dern_com)
  # Calcul de la différence entre date découverte du Compteur 000000 et date de dernière communication du compteur en arrêt de collecte correspondant
  # Différence entre deux dates ymd_hms = en minutes


df_Analyse_Finale["delta_2"] = df_Analyse_Finale["delta_2"].dt.total_seconds()



# résultat en secondes 
df_Analyse_Finale.insert(0,"probabilite_forte",df_Analyse_Finale["delta_2"].apply(lambda x: False if abs(x) > 10800 else True))
# probabilité forte si moins de 3H d'écart entre la dernière comm estimée et la découverte 



df_Finale = pd.merge(df_Analyse_Finale,df_EtatCourant_CK_PIL02,on='id_compteur',how ='left')
  # Vérifier que Compteur en arrêt de collecte n'a pas tenté de se redécouvrir ultérieurement à la date de découverte du C Découvert PRM USINE

df_Finale= df_Finale.assign(delta_3 = np.where(df_Finale.date_dern_pil02>df_Finale.date_decouverte, "KO", np.NaN))



df = pd.merge(df_Finale[df_Finale.delta_3=="nan"], df_Infos_Emplacement.rename(columns={'serialnum':'pdc_id_c'}),on = 'pdc_id_c',how = 'left') # jointure avec état logistique pour récupérer l'emplacement de chaque compteur



  # Je consitue mon fichier final en sélectionnant les champs nécessaires +1 renommage
df_Fichier = df[['dr','numero_da','id_prm','pdc_id','pdc_id_c','pdk_com','date_decouverte','id_compteur','date_arret_collecte','prm_c_arret_collecte','emplacement','type','sous_type','id_compteur']]


df_Fichier = df_Fichier.rename(columns={'id_compteur':'c_arret_collecte'})

import os 
directory = os.getcwd()
rep=directory+"/export_pilot_rapport_da/"

fc.split_df_to_csv(df_Fichier,999,rep,date_saisie,"DA_absence_crpose_prm_usine")

# zip du dossier
import shutil as sh
sh.make_archive('export_pilot_rapport_da','zip',rep)
stop = time.process_time()
print("Temps de traitement : ",stop-start,"secondes\n")
print("Fin de traitement, vous pouvez télécharger les données !\n")
