from dash import Dash, html, Input, Output, dash_table, State, dcc
import dash
import dash_bootstrap_components as dbc
import os
directory = os.getcwd()


app = Dash(__name__, external_stylesheets=[dbc.themes.CYBORG])

app.layout = html.Div(children=[
                html.H1('Choix script:', style={"text-align": "center","color":"blue",'font-size':'200%',"background-image": directory+"enedis.jpg"}),
  
            dbc.Container(
    [
            dbc.Row(
                [
                dbc.Col(
                    [
                        html.Div([
                dcc.RadioItems(id="my_choice",options = 
                   [
                       {'label': "pilot_rapport_da", 'value': 'DA_absence_crpose_prm_usine'},
                       {'label': "Ecart_PRM", 'value': 'Ecart_PRM'},
                       {'label': "TEMPO-EJP", 'value': 'tempo_ejp'},
                       {'label': "Nettoyage-Da", 'value': 'net_da'},
                       {'label': "ecart_techno_cpl", 'value': 'ecart_cpl'}
                   ],
                   value='Ecart_PRM',labelStyle = {'display':'block','font-size':'150%','font-family':'courier','padding':'30px'}
                ),
                
        ]),
                       
                    ]   
                ),
                dbc.Col([
                    
                        html.Div(id = 'check_output',style={"color":"red",'font-size':'150%','padding':'30px'})
                ]),
                    
                dbc.Col(
                    [
                        dbc.Button(
                            "Execute script", id="btn_exe",style={"color":"green",'font-size':'150%'}
                        ),
                        dbc.Row(
                            dbc.Button(
                            "Télécharger les données", id="btn_dl",style={"color":"green",'font-size':'150%'}
                        ),
                            
                        ),
                        dcc.Download(id="download"),
                        dbc.Col(
                    [html.H6("Ne pas télécharger avant d'executer le script svp !!!", style={"text-align": "center","color":"red",'font-size':'100%'})]
                )
                    ]
                ),
            ]
        ),
    ]) ,
]
)

 



@app.callback(
   
    Output(component_id = 'check_output',component_property = 'children'),
    Input("my_choice", "value") 
)
def update_output_div(my_choice_value):
    return f'Vous avez choisi : {my_choice_value}, cliquez sur executer et suivez les instructions du script dans le terminal svp !'

@app.callback(
    Output("my_choice", "children"),
    Input("btn_exe", "n_clicks"),
    State("my_choice", "value")

)
def run_script(n_clicks,my_choice_value):
    script_pilot_rapport_da = "/pilot_rapport_da_for_main.py"
    script_Ecart_PRM = "/ecart_prm_for_main.py"  
    script_TEMPO_EJP = "/tempo-EJP_for_main.py"
    script_Nettoyage_Da = "/nettoyage_da_for_main.py"  
    script_ecart_techno_cpl = "/ecart_techno_cpl_for_main.py"   
    ctx = dash.callback_context
 
    if ctx.triggered:
        button_id = ctx.triggered[0]['prop_id'].split('.')[0]
        if button_id == "btn_exe":
            if my_choice_value == 'DA_absence_crpose_prm_usine':
                exec(open(directory+script_pilot_rapport_da).read())
                return True
            elif my_choice_value == 'Ecart_PRM':
                exec(open(directory+script_Ecart_PRM).read()) 
                return True
            elif my_choice_value == 'tempo_ejp':
                exec(open(directory+script_TEMPO_EJP).read())
                return True
            elif my_choice_value == 'net_da':
                exec(open(directory+script_Nettoyage_Da).read())
                return True
            elif my_choice_value == 'ecart_cpl':
                exec(open(directory+script_ecart_techno_cpl).read())
                return True
        else:
            return False
        
@app.callback(
    Output('download','data'),
    Input("btn_dl", "n_clicks"),
    State("my_choice", "value"),
    prevent_initial_call=True,
)   

def dl_data_zipped(n_clicks,my_choice_value):          
    if my_choice_value == 'DA_absence_crpose_prm_usine':
        return dcc.send_file(directory+ "/export_pilot_rapport_da.zip")
            
    elif my_choice_value == 'Ecart_PRM':
        return dcc.send_file(directory+ "/export_ecart_prm.zip")
            
    elif my_choice_value == 'tempo_ejp':
        return dcc.send_file(directory+ "/export_tempo_ejp.zip")
                
    elif my_choice_value == 'net_da':
        return dcc.send_file(directory+ "/export_nettoyage_da.zip")
              
    elif my_choice_value == 'ecart_cpl':
        return dcc.send_file(directory+ "/export_ecart_cpl.zip")         
              
if __name__ == "__main__":
    app.run_server(port=8881, host='0.0.0.0')    


