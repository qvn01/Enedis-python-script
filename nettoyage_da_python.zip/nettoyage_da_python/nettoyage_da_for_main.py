# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import functions as fc
import imlconnect
from datetime import datetime, timedelta
import time
start = time.process_time()

print("Ce script sert à identifier les dossiers d'analyses qui doivent être clos par Hypervision")
print("DA concernés : 30,64,25,38,23,24,39,28,42,27,54,22,61,26,59,29,56")
print("Motifs de nettoyage:  DA non clos alors que C remplacé, DA non clos alors que C déposé, DA Défaillance Mat non clos alors que C a recollecté, DA Défaillance Mat non clos alors que C coupé au CCPI")

print("Entrez la date du jour svp ?\n")

j = input("Jour ? (format numérique svp!)\n")
while len(j)!=2:
    j = input("Jour ? (2 caractères et format numérique svp!)\n")
while True:
    try:
        val = int(str(j))
        while val<1 or val>31:
            j = input("Jour ? Entre 01 et 31 svp!)\n") 
            val = int(str(j))
    except ValueError:
        # Not a valid number
        print("Ce n'est pas un nombre entier\n")
        j = input("Jour ? (format numérique svp!)\n")
    else:
        print("Succès !\n")
        # No error; stop the loop
        break  

m = input("Mois ? (format numérique svp!)\n")
while len(m)!=2:
    m = input("Mois ? (2 caractères et format numérique svp!)\n")
while True:
    try:
        val1 = int(str(m))
        while val1<1 or val1>12:
            m = input("Mois ? Entre 01 et 12 svp!)\n") 
            val1 = int(str(m))
    except ValueError:
        # Not a valid number
        print("Ce n'est pas un nombre entier\n")
        m = input("Mois ? (format numérique svp!)\n")
    else:
        print("Succès !\n")# No error; stop the loop
        break

a = input("Année en cours? (format numérique svp!)\n")
while len(a)!=4:
    a = input("Année ? (4 caractères et format numérique svp!)\n")
while True:
    try:
        val2 = int(str(a))
        while val2!=datetime.now().year:
            a = input("Année doit être année en cours svp!)\n") 
            val2 = int(str(a))
    except ValueError:
        # Not a valid number
        print("Ce n'est pas un nombre entier\n")
        a = input("Année ? (format numérique svp!)\n")
    else:
        print("Succès !\n")# No error; stop the loop
        break

date_saisie = pd.to_datetime(str(val2)+"-"+str(val1)+"-"+str(val)).strftime("%Y-%m-%d")

print("1. On cherche tous les DA non clos pour les dysfonctionnements sélectionnés (TDY_ID), et dont la création est antérieure à J-7,\n il faut donc retirer 7 jours pour l'analyse")
Q = input("Voulez retirer des jours pour l'analyse ? oui ou non ?\n")
while Q!='oui' and Q!='non':
    print("Ecrivez correctement oui ou non en minuscule svp!\n")
    Q = input("Voulez retirer des jours à la date d'analyse ? oui ou non ?\n")
if Q=="oui":
    jour_à_retirer = input("Entrer le nombre de jour à retirer svp ?\n")
    while True:
        try:
            jour_à_retirer = int(str(jour_à_retirer))
        except ValueError:
            print("Ce n'est pas un nombre entier\n")
            jour_à_retirer = input("Entrez un nombre entier svp ?\n")
        else:
            print("Succès !\n")
            break
    date_analyse = pd.to_datetime(date_saisie) - timedelta(days=jour_à_retirer)
    date_analyse = date_analyse.strftime("%Y-%m-%d")

elif Q=='non':
    date_analyse = pd.to_datetime(date_saisie) - timedelta(days=0)
    date_analyse = date_analyse.strftime("%Y-%m-%d")
print("La date d'analyse est : \n",date_analyse) 
print("La date saisie est : \n",date_saisie)
print("Veuillez attendre jusqu'à la fin du traitement svp !\n")

my_conn_sup = imlconnect.Sql("lsup_conn", 
                  key_path='/var/projects/iml/rstudio/D86553/python_conn/imlconnect.key', 
                  config_file_path='/var/projects/iml/rstudio/D86553/python_conn/config_imlconnect.yml',
                  open_connection=True)


df_Liste_DA_C = my_conn_sup.query("select LOC_CODE DR, DAN_NUMERO_DOSSIER NUMERO_DA, TDY.TDY_LIBELLE TYPE_DA, TDY_CODE DYSF,PDC_ID PDC, PDC_ID_PRM_CONSO PRM, STC_LIBELLE STATUT_PDC, PDC_ID_C,utl_raw.cast_to_varchar2(dbms_lob.substr(DYS_SPECIFICITE)) SPECIFICITE from lspmet.t_dossier_analyse DA join lspmet.t_dysfonctionnement DYS on DYS.DYS_ID= DA.DAN_DYSFONCTIONNEMENT_FK JOIN lspmet.T_REF_TYPE_DYSFONCTIONNEMENT TDY ON DYS.DYS_TYPE_DYSFONCTIONNEMENT_FK = TDY.TDY_ID join lspmet.T_PDC on DYS_ID_OBJET=PDC_ID join lspmet.T_REF_STATUT_C on PDC_STATUT_FK=STC_ID join lspmet.t_localisation_dossier lod on lod.lod_dossier_fk = da.dan_id join lspmet.t_ref_localisation_erdf loc on loc.loc_id=lod.lod_localisation_fk WHERE TDY_ID in (30,64,25,38,23,24,39,28,42,27,54,22,61,26,59,29,56) and DAN_STATUT_DOSSIER_ANALYSE_FK=2 and dan_date_creation < to_date('"+ date_analyse + "','yyyy-mm-dd')")

df_Liste_DA_C = df_Liste_DA_C.assign(id_c_da ='')
for i in df_Liste_DA_C.specificite.index:
    index_debut = df_Liste_DA_C.specificite[i].find('PDC')-14
    index_fin = index_debut+12
    df_Liste_DA_C.id_c_da[i] = df_Liste_DA_C.specificite[i][index_debut:index_fin]



sql_ini = "select COMPTEUR_ID from lptdwh_ods.compteur c inner join filter_list f on f.val = c.compteur_id"
sql = fc.create_sql_with_df(df_Liste_DA_C,'id_c_da',sql_ini)



my_conn_pilot = imlconnect.Sql("pilot_conn", 
                      key_path='/var/projects/iml/rstudio/D86553/python_conn/imlconnect.key', 
                      config_file_path='/var/projects/iml/rstudio/D86553/python_conn/config_imlconnect.yml',
                      open_connection=True)

df_PilotCompteur = my_conn_pilot.query(sql)

df_Liste_DA_C_1 = df_Liste_DA_C.merge(df_PilotCompteur.rename(columns={'compteur_id': 'id_c_da'}),on = 'id_c_da', how = 'inner')

df_Remplace_ou_Depose = df_Liste_DA_C_1[df_Liste_DA_C_1.id_c_da != df_Liste_DA_C_1.pdc_id_c]

df_Remplace_ou_Depose = df_Remplace_ou_Depose.assign(categorie = np.where(df_Remplace_ou_Depose.pdc_id_c.isnull()==True,'Déposé','Remplacé'))

df_Liste_DA_C_Prodef_NR = df_Liste_DA_C_1.query("type_da=='C - Défaillance matériel' and pdc_id_c==id_c_da").assign(categorie = 'Non Remplacé')

df_Liste_DA_C_DemandeInter_NR = df_Liste_DA_C_1[df_Liste_DA_C_1.type_da.isin(['C - Demande d\'intervention','C - Demande d\'intervention en masse'])]
df_Liste_DA_C_DemandeInter_NR = df_Liste_DA_C_DemandeInter_NR.query("pdc_id_c==id_c_da").assign(categorie = 'Non Remplacé')                                                

sql_ini1 = "select DAN_NUMERO_DOSSIER NUMERO_DA,COM_COMMENTAIRE from lspmet.t_dossier_analyse da inner join filter_list f on f.val = da.dan_numero_dossier inner join lspmet.t_commentaire_da comm on da.dan_id = comm.com_da_id_fk"
sql1 = fc.create_sql_with_df(df_Liste_DA_C_DemandeInter_NR,'numero_da',sql_ini1)

df_Comm_DA_DemandeInter = my_conn_sup.query(sql1)

df_Comm_DA_DemandeInter = df_Comm_DA_DemandeInter[df_Comm_DA_DemandeInter.com_commentaire.str.contains("PRODEF|ne communique|silencieux|LTE|sans collecte|non collectant|non communicant|défaillant|C HS|C perdu|arrivée haute|bagotant|bagottant|itron ah|silen|pas de collecte|figé|tonemask|plus com|muet|compteur HS|plus de com|plus de com|pas de collecte|plus de collecte|défaillance|injoignable|Abs de com|pro def",case=False,na=False)==True].groupby(by='numero_da',as_index=False).sum()

df_Liste_DA_C_DemandeInter_NR = df_Liste_DA_C_DemandeInter_NR.merge(df_Comm_DA_DemandeInter.drop('com_commentaire',axis=1),on = 'numero_da', how='inner')

df_Liste_DA_C_Prodef_Inter_NR = pd.concat([df_Liste_DA_C_DemandeInter_NR,df_Liste_DA_C_Prodef_NR])

date_saisie = pd.to_datetime(str(val2)+"-"+str(val1)+"-"+str(val)).strftime("%Y-%m-%d")
print("Il faut maintenant retirer 1 jour pour la collecte de données dans pilot\n") 
Q = input("Voulez retirer des jours ? oui ou non ?\n")
while Q!='oui' and Q!='non':
    print("Ecrivez correctement oui ou non en minuscule svp!\n")
    Q = input("Voulez retirer des jours à la date d'analyse ? oui ou non ?\n")
if Q=="oui":
    jour_à_retirer = input("Entrer le nombre de jour à retirer svp ?\n")
    while True:
        try:
            jour_à_retirer = int(str(jour_à_retirer))
        except ValueError:
            print("Ce n'est pas un nombre entier\n")
            jour_à_retirer = input("Entrez un nombre entier svp ?\n")
        else:
            print("Succès !\n")
            break

    date_analyse1 = pd.to_datetime(date_saisie) - timedelta(days=jour_à_retirer)
    date_analyse1 = date_analyse1.strftime("%Y-%m-%d")

elif Q=='non':
    date_analyse1 = pd.to_datetime(date_saisie) - timedelta(days=0)
    date_analyse1 = date_analyse1.strftime("%Y-%m-%d")
print("La date d'analyse pour pilotcollecte est : \n",date_analyse1) 
print("La date saisie est : \n",date_saisie)
print("Veuillez attendre jusqu'à la fin du traitement svp !\n")
sql_ini1 = "select ID_COMPTEUR,  ID_PDC, NB_JOUR_COLLECTE,NB_JOUR_NON_COLLECTE from lptdwh_dmt.fait_pdc fpdc inner join filter_list f on f.val = fpdc.id_pdc where id_jour=to_date('"+ date_analyse1 + "','yyyy-mm-dd')"
sql1 = fc.create_sql_with_df(df_Liste_DA_C_Prodef_Inter_NR,'pdc',sql_ini1)

df_PilotCollecte = my_conn_pilot.query(sql1)

df_Liste_DA_C_Prodef_Inter_NR_Reprise = df_Liste_DA_C_Prodef_Inter_NR.merge(df_PilotCollecte.rename(columns={'id_pdc':'pdc'}), on = 'pdc', how = 'left').query("nb_jour_collecte>0 and nb_jour_non_collecte<=15") 

CCPI= pd.read_csv("/var/projects/iml/rstudio/Perf/INDUS/PROD/MeteOp/input/exclusions_ccpi_ginko.csv",sep=";",dtype=str)

df_Liste_DA_C_Prodef_Inter_NR_CCPI = df_Liste_DA_C_Prodef_Inter_NR.merge(CCPI.rename(columns={'ID_COMPTEUR':'id_c_da'}), on = 'id_c_da', how = 'inner')                                                                   

df_Nettoyage_Rempl = df_Remplace_ou_Depose[df_Remplace_ou_Depose.categorie =='Remplacé'][['numero_da','type_da','dysf','pdc','prm']].assign(cat='Remplacé')

df_Nettoyage_Dep = df_Remplace_ou_Depose[df_Remplace_ou_Depose.categorie =='Déposé'][['numero_da','type_da','dysf','pdc','prm']].assign(cat='Déposé')

df_Nettoyage_Prodef_Inter_Coll = df_Liste_DA_C_Prodef_Inter_NR_Reprise[['numero_da', 'type_da', 'dysf','pdc', 'prm']].assign(cat='Reprise Collecte')

df_Nettoyage_Prodef_Inter_CCPI = df_Liste_DA_C_Prodef_Inter_NR_CCPI[['numero_da', 'type_da', 'dysf', 'pdc', 'prm']].assign(cat='Coupure CCPI')

df_Nettoyage = pd.concat([df_Nettoyage_Rempl,df_Nettoyage_Dep,df_Nettoyage_Prodef_Inter_Coll,df_Nettoyage_Prodef_Inter_CCPI])

df_Nettoyage_1 = df_Nettoyage.copy()
df_Nettoyage_1.type_da = np.where( (df_Nettoyage_1.dysf =='DYS_C_DEFAILLANCE_MATERIEL') & (df_Nettoyage_1.numero_da.str[:8] >'DA210613') ,'C - Défaillance matériel V2',df_Nettoyage_1.type_da)

Stats_Metropole = df_Nettoyage_1[~df_Nettoyage_1.prm.str[:3].isin(['757','761','762','763','764'])].assign(nb_da=1).groupby(by='cat',as_index=False).nb_da.sum()


Stats_SEI = df_Nettoyage_1[df_Nettoyage_1.prm.str[:3].isin(['757','761','762','763','764'])].assign(nb_da=1).groupby(by='cat',as_index=False).nb_da.sum()


Action_LSUP = df_Nettoyage_1[['numero_da', 'dysf', 'pdc']]
Action_LSUP = Action_LSUP.reset_index(drop=True)

import os 
directory = os.getcwd()
rep=directory+"/export_nettoyage_da/"

fc.split_df_to_csv(Action_LSUP,999,rep,date_saisie,"Action_LSUP")
fc.split_df_to_csv(Stats_Metropole,999,rep,date_saisie,"Stats_Metropole")
fc.split_df_to_csv(Stats_SEI,999,rep,date_saisie,"Stats_SEI")
# zip du dossier
import shutil as sh
sh.make_archive('export_nettoyage_da','zip',rep)
stop = time.process_time()
print("Fin de traitement , vous pouvez télécharger les données !\n")
print("Temps de traitement : ",stop-start, "secondes")

